"use client"

import type { ChatMessage } from "@/types/chat"

interface ChatMessageProps {
  message: ChatMessage
}

export default function ChatMessageBubble({ message }: ChatMessageProps) {
  const isUser = message.role === "user"

  return (
    <div className={`flex ${isUser ? "justify-end" : "justify-start"} mb-4`}>
     <div
  className={`max-w-[75%] rounded-2xl px-4 py-3 text-sm leading-relaxed wrap-break-word overflow-hidden ${
    isUser
      ? "bg-blue-600 text-white rounded-br-sm"
      : "bg-gray-100 text-gray-900 rounded-bl-sm"
  }`}
>
        {message.content || (
          <span className="inline-flex gap-1">
            <span className="animate-bounce">●</span>
            <span className="animate-bounce" style={{ animationDelay: "0.1s" }}>●</span>
            <span className="animate-bounce" style={{ animationDelay: "0.2s" }}>●</span>
          </span>
        )}
        {message.isStreaming && message.content && (
          <span className="ml-1 inline-block w-0.5 h-4 bg-gray-500 animate-pulse align-middle" />
        )}
      </div>
    </div>
  )
}
